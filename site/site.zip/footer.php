<footer>
    <ul>
        <li>&copy;2022 Tous droits r&eacute;serv&eacute;s</li>
        <li><a href="mentionsLegales.php" title="Consultez les mentions l&eacute;gales"> Mentions L&eacute;gales </a></li>
        <li><a href="cgv.php" title="Consultez les conditions g&eacute;n&eacute;rales de vente"> CGV </a></li>
    </ul>        
</footer>
</body>
</html>